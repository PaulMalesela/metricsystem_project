package com.ayo.holding.metrics.convertion.servcies;

public interface MetricsImperialConversion {

   /*
    * 
    * @param convert ,value to be converted
    */
	public double metricsConversion(double convert);
	
	/*
	    * 
	    * @param convert ,value to be converted
	    * 
	    * converting celsius to fahrenheit
	    */
		public double imperialConversion(double convert);
}
