package com.ayo.holding.metrics.convertion.servcies;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Service;

import com.ayo.holding.metrics.enums.TypesOfMetrcisConversionSystems;
@Service
public class MetricsConversionService {
	
	
	private  MetricsImperialConversion metricsImperialConversion;
	private final ConversionService conversionServices;
	private HttpStatus status;
	
	public MetricsConversionService(final ConversionService conversionServices) {
	
		this.conversionServices=conversionServices;
		

	}
	  public ResponseEntity<String> convert(final Double convertedValue,final @NonNull String measurementType, final @NonNull String metricsSystem)
	            throws IllegalArgumentException {
		  
	      double converted=0;
	      try {
	    	       metricsImperialConversion= conversionServices.getConversionService(metricsSystem);
	    	   
	    	       if(measurementType.equalsIgnoreCase("Metric")) {
	    	    	   
	    	    	   converted = metricsImperialConversion.metricsConversion(convertedValue);
	    	    	   
	    	       }
	    	       else if(measurementType.equalsIgnoreCase("Imperial"))  {
	    	    	   converted= metricsImperialConversion.imperialConversion(convertedValue);
	    	       }
	    	       status = HttpStatus.OK;
	                
	            } catch (IllegalArgumentException e) {
	                return new ResponseEntity<String>(e.getMessage(), HttpStatus.BAD_REQUEST);
	            }

	       
	        return new ResponseEntity<String>(String.valueOf(converted), status);
	    }

	
	 public ResponseEntity<List<String>> getReadMeasurementTypes() {
	        return new ResponseEntity<>(Arrays.stream(TypesOfMetrcisConversionSystems.values()).map(TypesOfMetrcisConversionSystems ::name).collect(Collectors.toList()), HttpStatus.OK);
	    }


}
