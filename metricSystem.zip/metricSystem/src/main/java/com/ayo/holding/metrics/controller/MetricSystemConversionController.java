package com.ayo.holding.metrics.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ayo.holding.metrics.convertion.servcies.MetricsConversionService;

import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

import java.util.List;

@RestController
@RequestMapping(value = "/convert")
public class MetricSystemConversionController {
   
	private final MetricsConversionService metricsConversionService;
	
     @Autowired
	public MetricSystemConversionController(final MetricsConversionService metricsConversionService) {
		this.metricsConversionService = metricsConversionService;

	}

    @RequestMapping(value = "/{convertedValue}/{measurementType}/{metricsSystem}",
            method = RequestMethod.GET,
            produces = {
                    APPLICATION_JSON_VALUE,
            })
	public ResponseEntity<String> convertMeasurement(@PathVariable Double convertedValue,
			@PathVariable String measurementType, @PathVariable String metricsSystem) {

		return metricsConversionService.convert(convertedValue, measurementType, metricsSystem);
	}
    
    @RequestMapping(value = "/readMeasurement",
            method = RequestMethod.GET,
            produces = {
                    APPLICATION_JSON_VALUE,
            })
    public ResponseEntity<List<String>> readMeasurementTypes() {
        return metricsConversionService.getReadMeasurementTypes();
    }
}
