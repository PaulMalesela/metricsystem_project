package com.ayo.holding.metrics.convertion.servcies;

import org.apache.commons.math3.util.Precision;
import org.springframework.stereotype.Service;

/**
 * 
 * LiquidMeasurementsService is used to convert gallons to litres 
 * litres to gallon
 *   *
 */
@Service
public class LiquidMeasurementsService implements MetricsImperialConversion{
  protected static final double GALLON_CONVERSTION_VALUE=4.546;
	
	public double metricsConversion(double gallonValue) {
		  return Precision.round(gallonValue * GALLON_CONVERSTION_VALUE, 2);
		
	}
	
	public double imperialConversion(double litresValues) {
		 return Precision.round(litresValues / GALLON_CONVERSTION_VALUE, 2);
		
	}

	
}
