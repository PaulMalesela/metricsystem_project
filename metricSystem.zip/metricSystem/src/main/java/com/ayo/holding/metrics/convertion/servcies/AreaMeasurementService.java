package com.ayo.holding.metrics.convertion.servcies;

import org.apache.commons.math3.util.Precision;
import org.springframework.stereotype.Service;
 /**
  * 
  * @AreaMeasurementService is used to convert acres to hectare 
  * hectares to acres
  *   *
  */
@Service
public class AreaMeasurementService implements MetricsImperialConversion {
  
	protected static final double HECTARE_CONVERSION_RATE= 2.471;
	
	/* Convert acres to hectares
	 * 
	 * (non-Javadoc)
	 * @see com.ayo.holding.metrics.convertion.MetricsImperialConversion#metricsConversion(double)
	 */

	public double metricsConversion( double convert) {
		
		return Precision.round(convert * HECTARE_CONVERSION_RATE,2);
	}


	public double imperialConversion(double convert) {
		
		return  Precision.round(convert /HECTARE_CONVERSION_RATE, 2);
	}

	

}
