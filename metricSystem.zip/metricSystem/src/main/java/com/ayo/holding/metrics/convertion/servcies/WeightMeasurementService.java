package com.ayo.holding.metrics.convertion.servcies;

import org.apache.commons.math3.util.Precision;
import org.springframework.stereotype.Service;
/**
 * 
 * WeightMeasurementService is used to convert Pounds to kilogram 
 * kilogram to Pounds
 *   *
 */
@Service
public class WeightMeasurementService implements MetricsImperialConversion {

	protected static final double POUND_CONVERSTION_VALUE =2.2046;
	
	public double metricsConversion(double convertValue) {
		
		 return Precision.round(convertValue / POUND_CONVERSTION_VALUE, 2);
	}


	public double imperialConversion(double convertValue) {
	
		return Precision.round(convertValue * POUND_CONVERSTION_VALUE, 2);
	}

	

}
