package com.ayo.holding.metrics.convertion.servcies;

import org.apache.commons.math3.util.Precision;
import org.springframework.stereotype.Service;

/**
 * 
 * TemperatureService is used to convert fahrenheit to celsius 
 * celsius to fahrenheit
 *   *
 */
@Service
public class TemperatureService implements MetricsImperialConversion {
	
	
	public double metricsConversion(double convertedValue) {
		
		   return Precision.round((((convertedValue-32)*5)/9), 2); 
	}

	public double imperialConversion(double convertedValue) {
		
		 return  Precision.round((((convertedValue*9)/5)+32),2);
	}



	
}
