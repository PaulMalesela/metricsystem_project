package com.ayo.holding.metrics.convertion.servcies;

import org.apache.commons.math3.util.Precision;
import org.springframework.stereotype.Service;

/**
 * 
 * LengthMeasurementService is used to convert miles to kilometres 
 * kilometeres to miles
 *   *
 */
@Service
public class LengthMeasurementService implements MetricsImperialConversion {
   protected static final double MILE_COVERSION_FORMULAR=  0.6214;
  
  /*
   * converting miles to kilometres
   * (non-Javadoc)
   * @see com.ayo.holding.metrics.convertion.servcies.MetricsImperialConversion#metricsConversion(double)
   */
	public double metricsConversion(double miles) {
		
		  return Precision.round(miles * MILE_COVERSION_FORMULAR, 2);
   
	
	}

	/*converting kilometers to miles
	 * (non-Javadoc)
	 * @see com.ayo.holding.metrics.convertion.MetricsImperialConversion#imperialConversion(double)
	 */

	public double imperialConversion(double kilometre) {
		
		return Precision.round( kilometre/ MILE_COVERSION_FORMULAR,2);
	}

	


}
