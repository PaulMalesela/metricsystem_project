package com.ayo.holding.metrics.enums;

public enum TypesOfMetrcisConversionSystems {
	AREA("Area"),TEMPERATURE("Temperature"),LIQUID("Liquid"),LENGTH("length"),WEIGHT("Weight");
	
	private String measurementType;
	
	private TypesOfMetrcisConversionSystems(String measurementType) {
		this.measurementType=measurementType;
	}
	

	public String  getMeasurementType() {
		return measurementType;
	}
}
