package com.ayo.holding.metrics.convertion.servcies;

import java.util.Arrays;

import org.springframework.stereotype.Component;

import com.ayo.holding.metrics.enums.TypesOfMetrcisConversionSystems;

@Component
public class ConversionService {

	public MetricsImperialConversion getConversionService(String metricsSystem) {

		MetricsImperialConversion metricConversion = null;
        if (metricsSystem == null || metricsSystem.isEmpty())
			 throw new RuntimeException("Conversion system can not be empty value"+
					 metricsSystem);
	
        if(TypesOfMetrcisConversionSystems.AREA.getMeasurementType().equalsIgnoreCase(metricsSystem)) {
		  	metricConversion = new AreaMeasurementService();
        }
        else if(TypesOfMetrcisConversionSystems.TEMPERATURE.getMeasurementType().equalsIgnoreCase(metricsSystem)) {
        		metricConversion = new TemperatureService();
        }
        else if(TypesOfMetrcisConversionSystems.LIQUID.getMeasurementType().equalsIgnoreCase(metricsSystem)) {	
        	metricConversion = new LiquidMeasurementsService();
        }
        else if(TypesOfMetrcisConversionSystems.LENGTH.getMeasurementType().equalsIgnoreCase(metricsSystem)) {
			metricConversion = new LengthMeasurementService();
        }
        else if(TypesOfMetrcisConversionSystems.WEIGHT.getMeasurementType().equalsIgnoreCase(metricsSystem)) {
				metricConversion = new WeightMeasurementService();
        }
        else {
        	   Arrays.toString(TypesOfMetrcisConversionSystems.values());
        	
				throw new IllegalArgumentException("Conversion system type " + metricsSystem + " is 1not recognised :"
						+ "                       Use the following system type "+Arrays.toString(TypesOfMetrcisConversionSystems.values()));
			}

		return metricConversion;
	}
}
