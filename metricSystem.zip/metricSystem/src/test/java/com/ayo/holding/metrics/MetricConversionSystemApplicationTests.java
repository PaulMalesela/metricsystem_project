package com.ayo.holding.metrics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MetricConversionSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
