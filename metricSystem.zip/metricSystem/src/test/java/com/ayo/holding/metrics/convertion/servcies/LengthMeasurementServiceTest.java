package com.ayo.holding.metrics.convertion.servcies;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class LengthMeasurementServiceTest {

	@InjectMocks
    protected LengthMeasurementService lengthService;

    @BeforeAll
    static void setup() {
        MockitoAnnotations.openMocks(LengthMeasurementServiceTest.class);
    }

    @Test
    public void when_convertingLengthInkilometre_expect_equivalentLengthInMiles() {
        assertEquals(17.7, lengthService.imperialConversion(11));
    }

    @Test
    public void when_convertingLengthInMiles_expect_equivalentLengthInKilometresm() {
        assertEquals(9.94, lengthService.metricsConversion(16));
    }

}
