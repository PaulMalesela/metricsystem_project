package com.ayo.holding.metrics.convertion.servcies;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
@ExtendWith(MockitoExtension.class)
public class AreaMeasurementServiceTest {

	    @InjectMocks
	    protected AreaMeasurementService  areaMeasurementService;

	    @BeforeAll
	    static void setup() {
	        MockitoAnnotations.openMocks(AreaMeasurementServiceTest.class);
	    }

	    @Test
	    public void when_convertingAreaInHectares_expect_equivalentAreaInAcres() {
	        assertEquals(8.09, areaMeasurementService.imperialConversion(20));
	    }

	    @Test
	    public void wwhen_convertingAreaInAcres_expect_equivalentAreaInHectares() {
	        assertEquals(30.15, areaMeasurementService.metricsConversion(12.2));
	    }


}
