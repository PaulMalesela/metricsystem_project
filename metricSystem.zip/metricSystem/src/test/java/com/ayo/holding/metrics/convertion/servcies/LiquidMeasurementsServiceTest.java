package com.ayo.holding.metrics.convertion.servcies;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class LiquidMeasurementsServiceTest {
   
	@InjectMocks
	protected LiquidMeasurementsService liquidService;
	
	
	 @BeforeAll
	    static void setup() {
	        MockitoAnnotations.openMocks(TemperatureServiceTest.class);
	    }

	    @Test
	    public  void when_convertingLiquidInLitres_expect_equivalentLiquidInGallons() {
	        
	        assertEquals(68.19, liquidService.metricsConversion(15));
	    }

	    @Test
	    public  void when_convertingLiquidInGallon_expect_equivalentLiquidInLitres() {
	            assertEquals(11.11, liquidService.imperialConversion(50.5));
	    }
}
