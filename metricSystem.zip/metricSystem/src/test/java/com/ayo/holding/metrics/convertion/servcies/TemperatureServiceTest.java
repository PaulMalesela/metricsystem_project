package com.ayo.holding.metrics.convertion.servcies;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import static org.junit.jupiter.api.Assertions.*;


@ExtendWith(MockitoExtension.class)
public class TemperatureServiceTest {

	 @InjectMocks
	    protected TemperatureService temperatureService;

	    @BeforeAll
	    static void setup() {
	        MockitoAnnotations.openMocks(TemperatureServiceTest.class);
	    }

	    @Test
	    public  void when_convertingTemperatureInFahrenheit_expect_equivalent_TemperatureInCelsius() {
	       
	        assertEquals(15.61, temperatureService.metricsConversion(60.1));
	    }

	    @Test
	    public  void when_convertingTemperatureInCelsiusSpecified_expect_equivalent_TemperatureInFahrenheit() {
	       
	        assertEquals(72.5, temperatureService.imperialConversion(22.5));
	    }

}
