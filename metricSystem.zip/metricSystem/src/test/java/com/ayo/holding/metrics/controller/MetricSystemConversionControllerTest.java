package com.ayo.holding.metrics.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class MetricSystemConversionControllerTest {
	
	  private final TestRestTemplate testRestTemplate = new TestRestTemplate();
	  private final HttpHeaders httpHeaders = new HttpHeaders();

	    
	    
	    @Test
	    public void givenACelsiusValueToConvert_whenExecuted_thenResponseContainsValueAndCorrectCode() {
	        double fahrenheit = 55.2;
	        double celsius = 12.89;
	        HttpEntity<String> entity = new HttpEntity<>(null, httpHeaders);
	        ResponseEntity<String> responseEntity = testRestTemplate.exchange(serviceURL(fahrenheit+"/metric/temperature"),
	                HttpMethod.GET,
	                entity,
	                String.class);

	        assertNotNull(responseEntity);
	        assertEquals(HttpStatus.OK.value(), responseEntity.getStatusCodeValue());
	        assertNotNull(responseEntity.getBody());
	        assertEquals(String.valueOf(celsius), responseEntity.getBody());
	    }

	    @Test
	    public void givenAFahrenheitValueToConvert_whenExecuted_thenResponseContainsValueAndCorrectCode() {
	        double celsius = 55.2;
	        double fahrenheit= 131.36;
	        HttpEntity<String> entity = new HttpEntity<>(null, httpHeaders);
	        ResponseEntity<String> responseEntity = testRestTemplate.exchange(serviceURL(celsius+"/imperial/temperature"),
	                HttpMethod.GET,
	                entity,
	                String.class);

	        assertNotNull(responseEntity);
	        assertEquals(HttpStatus.OK.value(), responseEntity.getStatusCodeValue());
	        assertNotNull(responseEntity.getBody());
	        assertEquals(String.valueOf(fahrenheit), responseEntity.getBody());
	    }


	    @Test
	    public void givenAnAcreValueToConvert_whenExecuted_thenResponseContainsValueAndCorrectCode() {
	        double acre = 55.2;
	        double hectare = 136.4;
	        HttpEntity<String> entity = new HttpEntity<>(null, httpHeaders);
	        ResponseEntity<String> responseEntity = testRestTemplate.exchange(serviceURL(acre+"/metric/area" ),
	                HttpMethod.GET,
	                entity,
	                String.class);

	        assertNotNull(responseEntity);
	        assertEquals(HttpStatus.OK.value(), responseEntity.getStatusCodeValue());
	        assertNotNull(responseEntity.getBody());
	        assertEquals(String.valueOf(hectare), responseEntity.getBody());
	    }

	    @Test
	    public void givenAHectareValueToConvert_whenExecuted_thenResponseContainsValueAndCorrectCode() {
	        double hectare = 55.2;
	        double acre = 22.34;
	        HttpEntity<String> entity = new HttpEntity<>(null, httpHeaders);
	        ResponseEntity<String> responseEntity = testRestTemplate.exchange(serviceURL(hectare+"/imperial/area/"),
	                HttpMethod.GET,
	                entity,
	                String.class);

	        assertNotNull(responseEntity);
	        assertEquals(HttpStatus.OK.value(), responseEntity.getStatusCodeValue());
	        assertNotNull(responseEntity.getBody());
	        assertEquals(String.valueOf(acre), responseEntity.getBody());
	    }

	    @Test
	    public void givenAMileValueToConvert_whenExecuted_thenResponseContainsValueAndCorrectCode() {
	        double mile = 55.2;
	        double kilometer = 34.3;
	        HttpEntity<String> entity = new HttpEntity<>(null, httpHeaders);
	        ResponseEntity<String> responseEntity = testRestTemplate.exchange(serviceURL(mile+"/metric/length"),
	                HttpMethod.GET,
	                entity,
	                String.class);

	        assertNotNull(responseEntity);
	        assertEquals(HttpStatus.OK.value(), responseEntity.getStatusCodeValue());
	        assertNotNull(responseEntity.getBody());
	        assertEquals(String.valueOf(kilometer), responseEntity.getBody());
	    }

	    @Test
	    public void givenKilometerValueToConvert_whenExecuted_thenResponseContainsValueAndCorrectCode() {
	        double mile = 159.96;
	        double kilometer = 99.40;
	        HttpEntity<String> entity = new HttpEntity<>(null, httpHeaders);
	        ResponseEntity<String> responseEntity = testRestTemplate.exchange(serviceURL(kilometer+"/imperial/length"),
	                HttpMethod.GET,
	                entity,
	                String.class);

	        assertNotNull(responseEntity);
	        assertEquals(HttpStatus.OK.value(), responseEntity.getStatusCodeValue());
	        assertNotNull(responseEntity.getBody());
	        assertEquals(String.valueOf(mile), responseEntity.getBody());
	    }

	    @Test
	    public void givenAGallonValueToConvert_whenExecuted_thenResponseContainsCorrectLitreValueAndCorrectCode() {
	        double gallon = 23;
	        double litre = 104.56;
	        HttpEntity<String> entity = new HttpEntity<>(null, httpHeaders);
	        ResponseEntity<String> responseEntity = testRestTemplate.exchange(serviceURL(gallon+"/metric/liquid" ),
	                HttpMethod.GET,
	                entity,
	                String.class);

	        assertNotNull(responseEntity);
	        assertEquals(HttpStatus.OK.value(), responseEntity.getStatusCodeValue());
	        assertNotNull(responseEntity.getBody());
	        assertEquals(String.valueOf(litre), responseEntity.getBody());
	    }

	    @Test
	    public void givenLitreValueToConvert_whenExecuted_thenResponseContainsCorrectGallonValueAndCorrectCode() {
	        double gallon = 2.07;
	        double litre = 9.40;
	        HttpEntity<String> entity = new HttpEntity<>(null, httpHeaders);
	        ResponseEntity<String> responseEntity = testRestTemplate.exchange(serviceURL(litre+"/imperial/liquid"),
	                HttpMethod.GET,
	                entity,
	                String.class);

	        assertNotNull(responseEntity);
	        assertEquals(HttpStatus.OK.value(), responseEntity.getStatusCodeValue());
	        assertNotNull(responseEntity.getBody());
	        assertEquals(String.valueOf(gallon), responseEntity.getBody());
	    }

	    @Test
	    public void givenPoundValueToConvert_whenExecuted_thenResponseContainsCorrectKilogramValueAndCorrectCode() {
	        double pound = 5.2;
	        double kilogram = 2.36;
	        HttpEntity<String> entity = new HttpEntity<>(null, httpHeaders);
	        ResponseEntity<String> responseEntity = testRestTemplate.exchange(serviceURL(pound+"/metric/weight"),
	                HttpMethod.GET,
	                entity,
	                String.class);

	        assertNotNull(responseEntity);
	        assertEquals(HttpStatus.OK.value(), responseEntity.getStatusCodeValue());
	        assertNotNull(responseEntity.getBody());
	        assertEquals(String.valueOf(kilogram), responseEntity.getBody());
	    }

	    @Test
	    public void givenKilogramValueToConvert_whenExecuted_thenResponseContainsCorrectPoundValueAndCorrectCode() {
	        double pound = 20.72;
	        double kilogram = 9.40;
	        HttpEntity<String> entity = new HttpEntity<>(null, httpHeaders);
	        ResponseEntity<String> responseEntity = testRestTemplate.exchange(serviceURL(kilogram+"/imperial/weight"),
	                HttpMethod.GET,
	                entity,
	                String.class);

	        assertNotNull(responseEntity);
	        assertEquals(HttpStatus.OK.value(), responseEntity.getStatusCodeValue());
	        assertNotNull(responseEntity.getBody());
	        assertEquals(String.valueOf(pound), responseEntity.getBody());
	    }

	   
	    @Test
	    public void givenWrongMetric_whenExecuted_thenResponseWithErrorCodeAndMessage() {
	        double litres = 9.40;
	        HttpEntity<String> entity = new HttpEntity<>(null, httpHeaders);

	        ResponseEntity<String> responseEntity = testRestTemplate.exchange(serviceURL(litres+"/imperial/measurement_typ"),
	                HttpMethod.GET,
	                entity,
	                String.class);

	        assertNotNull(responseEntity);
	        assertEquals(HttpStatus.BAD_REQUEST.value(), responseEntity.getStatusCodeValue());
	        assertNotNull(responseEntity.getBody());
	    }
    
	    
   private String serviceURL(final String uri) {
	   return "http://localhost:"+8080+"/convert/" + uri;
	}
}
