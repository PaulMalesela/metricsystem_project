package com.ayo.holding.metrics.convertion.servcies;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class WeightMeasurementServiceTest {
 

    @InjectMocks
    protected WeightMeasurementService weightService;

    @BeforeAll
    static void setup() {
        MockitoAnnotations.openMocks(WeightMeasurementServiceTest.class);
    }

    @Test
    public void when_convertingWeightInKilogram_expect_equivalentWeightInPound() {
        assertEquals(20.94, weightService.imperialConversion(9.5));
    }

    @Test
    public void when_convertingWeightInPound_expect_equivalentWeightInKilogram() {
        assertEquals(9.5, weightService.metricsConversion(20.94));
    }
}
